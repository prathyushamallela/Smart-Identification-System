package com.example.sis10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ShowGraph extends AppCompatActivity {

    private BarChart mbarChart;
    Bundle extras;
    String counts="";
    List<String> al = new ArrayList<String>();
    float k=0,uk=0;
    //uc=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_graph);

        mbarChart = findViewById(R.id.barchart);

        extras=getIntent().getExtras();

        /*System.out.println(extras.getInt("KCount"));
        System.out.println(extras.getInt("UKCount"));
        System.out.println(extras.getInt("UCCount"));*/


        if(extras != null) {
            //convert string to arraylist
            /*counts=extras.getString("Count");
            String str[] = counts.split(",");
            al = Arrays.asList(str);
            k=Integer.parseInt(al.get(0));
            uk=Integer.parseInt(al.get(1));
            uc=Integer.parseInt(al.get(2));*/
            k=extras.getInt("KCount");
            uk=extras.getInt("UKCount");
            //uc=extras.getInt("UCCount");

            //System.out.println(k+" "+uk+" "+uc);
        }


        ArrayList<BarEntry> entries = new ArrayList<BarEntry>();
        entries=dataValues(k,uk);

        BarDataSet bardataset = new BarDataSet(entries, "Known, Unknown");


        BarData data = new BarData(bardataset);
        //mbarChart.setLabelFor(0);
        mbarChart.setData(data); // set the data and list of labels into chart
        Description description = new Description();
        description.setText("Known:"+k+" ; "+"Unknown:"+uk);
        mbarChart.setDescription(description);  // set the description
        bardataset.setColors(ColorTemplate.COLORFUL_COLORS);
        mbarChart.animateY(5000);
    }

    @org.jetbrains.annotations.NotNull
    private ArrayList<BarEntry> dataValues(float k, float uk){
        ArrayList<BarEntry> dataVals = new ArrayList<BarEntry>();
        dataVals.add(new BarEntry(3,k));
        dataVals.add(new BarEntry(6,uk));
        //dataVals.add(new BarEntry(6,uc));
        return dataVals;
    }

}