package com.example.sis10;

import android.content.Context;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class FeedbackImageAdapter extends RecyclerView.Adapter<FeedbackImageAdapter.ImageViewHolder> {

    private Context mContext;
    private List<Uploader> mUploads;
    private onFeedbackItemClickListener mFeedbackListener;

    public FeedbackImageAdapter(Context context,List<Uploader> uploads){
        mContext =  context;
        mUploads = uploads;
    }

    @NonNull
    @Override
    public FeedbackImageAdapter.ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.feedback_item,parent,false);
        return new FeedbackImageAdapter.ImageViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull FeedbackImageAdapter.ImageViewHolder holder, int position) {

        Uploader uploadCurrent = mUploads.get(position);
        holder.textViewName.setText(uploadCurrent.getFamiliarity());
        Picasso.with(mContext)
                .load(uploadCurrent.getImageUrl())
                .placeholder(R.mipmap.ic_launcher)
                .fit()
                .centerCrop()
                .into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return mUploads.size();
    }

    public class ImageViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener,
    View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener {
        public TextView textViewName;
        public ImageView imageView;
        public Button btnKnown;
        public Button btnUnknown;

        //handle click events here


        public ImageViewHolder(@NonNull View itemView)  {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textViewFeedback);
            imageView = itemView.findViewById(R.id.imageViewSavedImageFeedback);


            /*btnKnown = itemView.findViewById(R.id.buttonFamiliarityKnown);
            btnUnknown = itemView.findViewById(R.id.buttonFamiliarityUnknown);*/
            itemView.setOnClickListener(this);
            itemView.setOnCreateContextMenuListener(this);
        }

        @Override
        public void onClick(View v) {
            if(mFeedbackListener != null){
                int position = getAdapterPosition();
                if(position != RecyclerView.NO_POSITION){
                    mFeedbackListener.onFeedbackItemClick(position);
                }
            }

        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            menu.setHeaderTitle("Select Action");
            MenuItem known = menu.add(Menu.NONE,1,1,"Known");
            MenuItem unknown = menu.add(Menu.NONE,2,2,"Unknown");
            MenuItem delete = menu.add(Menu.NONE,3,3,"Delete");

            known.setOnMenuItemClickListener(this);
            unknown.setOnMenuItemClickListener(this);
            delete.setOnMenuItemClickListener(this);

        }

        @Override
        public boolean onMenuItemClick(MenuItem item) {
            if(mFeedbackListener != null){
                int position = getAdapterPosition();
                if(position != RecyclerView.NO_POSITION){
                    switch(item.getItemId()){
                        case 1:
                            mFeedbackListener.onFeedbackKnownClick(position);
                            return true;
                        case 2:
                            mFeedbackListener.onFeedbackUnknownClick(position);
                            return true;
                        case 3:
                            mFeedbackListener.onFeedbackDeleteClick(position);
                            return true;

                    }
                }
            }

            return false;
        }
    }


    public interface onFeedbackItemClickListener{
        void  onFeedbackItemClick(int position);

        void onFeedbackKnownClick(int position);

        void onFeedbackUnknownClick(int position);

        void onFeedbackDeleteClick(int position);
    }

    public void setOnItemClickListener(onFeedbackItemClickListener listener){

        mFeedbackListener = listener;

    }
}
