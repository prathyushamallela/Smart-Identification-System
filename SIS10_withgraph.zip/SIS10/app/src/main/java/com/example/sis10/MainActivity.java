package com.example.sis10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button mImageFeedback;
    private Button mViewFamiliarity;

    private Button mViewAnalysis;
    private Button mSetThresholdView;

    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mViewFamiliarity = findViewById(R.id.buttonViewFamiliarity);
        mViewFamiliarity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openViewActivity();
            }
        });

        mImageFeedback = findViewById(R.id.buttonImageFeedback);
        mImageFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImageFeedback();
            }
        });

        mViewAnalysis = findViewById(R.id.buttonAnalyze);

       mViewAnalysis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openViewAnalysis();
            }
        });

       /*mSetThresholdView = findViewById(R.id.buttonSetThreshold);
       mSetThresholdView.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               openSetThresholdView();
           }
       });*/


    }


    public void openImageFeedback() {
        Intent imageFeedbackIntent = new Intent(this, Feedback.class);
        startActivity(imageFeedbackIntent);
    }


    public void openViewActivity() {
        Intent viewActivityIntent = new Intent(this, ViewFamiliarity.class);
        startActivity(viewActivityIntent);
    }

    public void openViewAnalysis() {
        Intent viewAnalysisIntent = new Intent(this, Analyzer.class);
        startActivity(viewAnalysisIntent);
    }

   /* public void openSetThresholdView() {
        Intent setThreshold = new Intent(this, EnableThreshold.class);
        startActivity(setThreshold);
    }*/

}