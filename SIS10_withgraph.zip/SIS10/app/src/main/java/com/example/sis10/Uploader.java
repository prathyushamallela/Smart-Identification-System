package com.example.sis10;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Uploader {
    private String mName;
    private String mImageUrl;
    private String mFamiliarity;
    private String mFamiliarityScore="0";
    private String mKey;

    private float mScore;
    private DatabaseReference mDatabaseRef;
    //private String mFamiliarityScore; //gets the score and displays it.



    public Uploader(){
        //empty constructor needed
    }

    /*public Uploader(String name, String imageUrl, String familiarity){

        if(name.trim().equals("")){
            name = "No Name";
        }

        mName=name;
        mImageUrl=imageUrl;
       // mFamiliarity=familiarity;


    }*/

    public Uploader(String name, String imageUrl,String familiarity){

        if(name.trim().equals("")){
            name = "No Name";
        }

        mName=name;
        mImageUrl=imageUrl;
        mFamiliarity=familiarity;


    }

    //upload to view historic data
    public Uploader(String imageUrl,String familiarity){
        mScore = Float.parseFloat(mFamiliarityScore);
        if(familiarity.trim().equals("")||familiarity.trim().equals("None")||familiarity.trim().equals("0")){
            familiarity = "No Familiarity";
        }
        /*mImageUrl=imageUrl;
        if(mScore>=80){
            mFamiliarity = "Known";
        }
        else {
            mFamiliarity = "Unknown";
        }*/
        //mFamiliarity=familiarity;
    }

    //upload to feedback
    public Uploader(String imageUrl){
        mImageUrl=imageUrl;
    }


    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getImageUrl() {
        return mImageUrl;
    }

    public void setImageUrl(String imageurl) {
        mImageUrl = imageurl;
    }

    public String getFamiliarity() {
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("ImagesCapturedFromSource");
        HashMap<String,Object> result = new HashMap<>();

        if(Float.parseFloat(getFamiliarityScore())>=80.0f) {
            mFamiliarity = "Known";

        }
        else {
            mFamiliarity = "Unknown";

        }
        result.put("familiarity",mFamiliarity);
        if(getKey()!=null)
            mDatabaseRef.child(getKey()).updateChildren(result);

        return mFamiliarity;
    }

    public void setFamiliarity(String familiarity) {
        if(Float.parseFloat(getFamiliarityScore())>=80.0f)
            mFamiliarity = "Known";
        else
            mFamiliarity = "Unknown";
            mFamiliarity = familiarity;
    }

    public void setFamiliarityScore(String familiarityscore){
        mFamiliarityScore=familiarityscore;
    }
    public String getFamiliarityScore(){
        return mFamiliarityScore;
    }

    @Exclude
    public String getKey(){
        return mKey;
    }

    @Exclude
    public void setKey(String key){
        mKey=key;
    }



}
