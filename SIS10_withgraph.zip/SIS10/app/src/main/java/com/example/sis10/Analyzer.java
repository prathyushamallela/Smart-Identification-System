package com.example.sis10;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.github.mikephil.charting.charts.BarChart;

public class Analyzer extends AppCompatActivity {

    private TextView mKnownCount;
    private TextView mUnknownCount;
    private TextView mUnclassifiedCount;

    private TextView mTextView;

    private TextView mShowGraph;

    private int kCount=0;
    private int uCount=0;
    private int unclassifiedCount=0;

    private FirebaseStorage mStorage;
    private DatabaseReference mDatabaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analyzer);
        mKnownCount = findViewById(R.id.countFamiliarityKnown);
        mUnknownCount = findViewById(R.id.countFamiliarityUnknown);
        //mUnclassifiedCount = findViewById(R.id.countUnclassified);

        mShowGraph = findViewById(R.id.showGraphAnalysis);


        mStorage = FirebaseStorage.getInstance();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("ImagesCapturedFromSource");

        //computing the number of knowns and unknowns




        FirebaseDatabase.getInstance().getReference().child("ImagesCapturedFromSource").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {



                for(DataSnapshot sn:snapshot.getChildren()){
                    HashMap<String,Object> res = new HashMap<>();
                    res.putAll((HashMap<String,Object>)sn.getValue());
                    String familiarity = null;
                    familiarity=res.get("familiarity").toString();
                    //System.out.println(familiarity);
                    if(familiarity.equalsIgnoreCase("Known"))
                        kCount++;
                    else if(familiarity.equalsIgnoreCase("Unknown"))
                        uCount++;
                    else
                        unclassifiedCount++;




                }
                //System.out.println(kCount);
                mKnownCount.setText(kCount+"");
                mUnknownCount.setText(uCount+"");
                //mUnclassifiedCount.setText(unclassifiedCount+"");

                mShowGraph.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        /*ArrayList<String> values = new ArrayList<String>();
                        values.add(kCount+"");
                        values.add(uCount+"");
                        values.add(unclassifiedCount+"");*/

                        openGraphAnalysis(kCount,uCount);
                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                //Toast.makeText(this,"Known click at position: ", Toast.LENGTH_SHORT).show();
                /*Toast.makeText(this,
                        "Probably a connection or a Database problem. Please try again, or contact the adminstrator!",
                        Toast.LENGTH_SHORT).show();*/
            }
        });


    }


    public void openGraphAnalysis(int k, int uk){
        Intent openGraphIntent = new Intent(this, ShowGraph.class);
        openGraphIntent.putExtra("KCount",k);
        openGraphIntent.putExtra("UKCount",uk);
        //openGraphIntent.putExtra("UCCount",uc);

        startActivity(openGraphIntent);

    }




}