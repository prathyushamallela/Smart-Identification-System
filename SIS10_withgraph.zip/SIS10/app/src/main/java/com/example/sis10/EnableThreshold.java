package com.example.sis10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EnableThreshold extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enable_threshold);
    }
}