package com.example.sis10;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Feedback extends AppCompatActivity implements FeedbackImageAdapter.onFeedbackItemClickListener{


    private RecyclerView mRecyclerView;
    private FeedbackImageAdapter mAdapter;

    private ProgressBar mProgressCircle;

    private FirebaseStorage mStorage;
    private DatabaseReference mDatabaseRef;
    private ValueEventListener mDBListener;


    private List<Uploader> mUploads;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        mRecyclerView = findViewById(R.id.recyclerViewFeedback);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mProgressCircle = findViewById(R.id.progressCircleFeedback);

        mUploads = new ArrayList<>();
        mAdapter = new FeedbackImageAdapter(Feedback.this, mUploads);
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setOnItemClickListener(Feedback.this);

        //initialise the firebase storage
        mStorage = FirebaseStorage.getInstance();


        mDatabaseRef = FirebaseDatabase.getInstance().getReference("ImagesCapturedFromSource");

        mDBListener = mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                //the list from db is stored, when the list is cleared the
                //modified list will be stored in the firebase database
                mUploads.clear(); //clears the list

                for(DataSnapshot snap:snapshot.getChildren()){
                    Uploader uploader = snap.getValue(Uploader.class);
                    uploader.setKey(snap.getKey());
                    mUploads.add(uploader);
                }

                //mAdapter = new FeedbackImageAdapter(Feedback.this, mUploads);
                //mRecyclerView.setAdapter(mAdapter);

                //here for onclick functions in menu

                //mAdapter.setOnItemClickListener(Feedback.this);
                mAdapter.notifyDataSetChanged();



                mProgressCircle.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Toast.makeText(Feedback.this,error.getMessage(),Toast.LENGTH_SHORT).show();
                mProgressCircle.setVisibility(View.INVISIBLE);

            }
        });
    }

    @Override
    public void onFeedbackItemClick(int position) {
        //Toast.makeText(this,"Normal click at position: "+ position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onFeedbackKnownClick(int position) {

        //Toast.makeText(this,"Known click at position: "+ position, Toast.LENGTH_SHORT).show();
        Uploader selectedUploaderItem = mUploads.get(position);
        final String selectedKey = selectedUploaderItem.getKey();
        HashMap<String,Object> result = new HashMap<>();
        result.put("familiarity","Known");

        //mDatabaseRef.child(selectedKey).child("familiarity")
        mDatabaseRef.child(selectedKey).updateChildren(result);

        //Toast.makeText(this,mDatabaseRef.child(selectedKey).child("familiarity").toString(), Toast.LENGTH_SHORT).show();

        //Toast.makeText(this,mDatabaseRef.child(selectedKey).toString(), Toast.LENGTH_SHORT).show();


    }

    @Override
    public void onFeedbackUnknownClick(int position) {

        //Toast.makeText(this,"Unknown click at position: "+ position, Toast.LENGTH_SHORT).show();

        Uploader selectedUploaderItem = mUploads.get(position);
        final String selectedKey = selectedUploaderItem.getKey();
        HashMap<String,Object> result = new HashMap<>();
        result.put("familiarity","Unknown");
        //mDatabaseRef.child(selectedKey).child("familiarity")
        mDatabaseRef.child(selectedKey).updateChildren(result);

    }

    @Override
    public void onFeedbackDeleteClick(int position) {
        //Toast.makeText(this,"Delete click at position: "+ position, Toast.LENGTH_SHORT).show();
        Uploader selectedUploaderItem = mUploads.get(position);
        final String selectedKey = selectedUploaderItem.getKey();


        StorageReference imageRef = mStorage.getReferenceFromUrl(selectedUploaderItem.getImageUrl());
        imageRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                mDatabaseRef.child(selectedKey).removeValue();
                Toast.makeText(Feedback.this, "Deleted Image!",Toast.LENGTH_SHORT).show();
            }
        });

       /*         .addOnFailureListener(
                Toast.makeText(Feedback.this,"Failed deleting the Image, contact the operator!",Toast.LENGTH_SHORT).show();
        );*/
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        mDatabaseRef.removeEventListener(mDBListener);
    }
}