package com.example.sis10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button mImageFeedback;
    private Button mViewFamiliarity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mViewFamiliarity = findViewById(R.id.buttonViewFamiliarity);
        mViewFamiliarity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openViewActivity();
            }
        });

        mImageFeedback = findViewById(R.id.buttonImageFeedback);
        mImageFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImageFeedback();
            }
        });



    }


    public void openImageFeedback() {
        Intent imageFeedbackIntent = new Intent(this, Feedback.class);
        startActivity(imageFeedbackIntent);
    }


    public void openViewActivity() {
        Intent viewActivityIntent = new Intent(this, ViewFamiliarity.class);
        startActivity(viewActivityIntent);
    }



}